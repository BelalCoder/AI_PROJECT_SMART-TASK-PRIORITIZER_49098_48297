let chartInstance = null;

window.onload = function () {
    fetch('/clear_tasks', { method: 'POST' });
    checkModelStatus();
};

function checkModelStatus() {
    fetch('/model_status')
    .then(res => res.json())
    .then(data => {
        const bar = document.getElementById('model-status-bar');
        const label = document.getElementById('model-label');
        if (data.trained) {
            bar.className = 'model-bar trained';
            label.textContent = `Active — trained on ${data.samples} samples | Weights → Importance: ${data.importance_weight}, Urgency: ${data.urgency_weight}, Time: ${data.time_weight}`;
        } else {
            bar.className = 'model-bar untrained';
            label.textContent = 'Not trained';
        }
    });
}

function addTask() {
    const text = document.getElementById('task-input').value.trim();
    if (!text) { alert('Please describe a task before adding it.'); return; }

    fetch('/ner_parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
    })
    .then(res => res.json())
    .then(data => {
        const extracted = data.extracted;
        if (!extracted || !extracted.task) {
            alert('Unable to parse task description.');
            return;
        }

        return fetch('/add_task', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                task: extracted.task,
                importance: extracted.importance,
                urgency: extracted.urgency,
                time: extracted.time
            })
        });
    })
    .then(res => {
        if (!res) return;
        return res.json();
    })
    .then(data => {
        if (!data || !data.task) return;
        const t = data.task;
        alert(`✅ Task Added: ${t.task}\nImportance: ${t.importance} | Urgency: ${t.urgency} | Time: ${t.time}h`);
        document.getElementById('task-input').value = '';
        sendTasks();
    })
    .catch(() => alert('Server error while adding the task.'));
}

function sendTasks() {
    fetch('/tasks')
    .then(res => res.json())
    .then(tasks => {
        if (tasks.length === 0) {
            document.getElementById('result').innerHTML = '<p class="empty">No tasks added yet!</p>';
            document.getElementById('chart-section').style.display = 'none';
            return;
        }

        let html = '<h2>📋 Prioritized Tasks</h2>';
        tasks.forEach((t, i) => {
            const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`;
            const maxScore = 5;
            const pct = Math.min(100, Math.round((t.score / maxScore) * 100));
            const barColor = pct >= 70 ? '#22c55e' : pct >= 40 ? '#f59e0b' : '#ef4444';

            html += `
            <div class="task-card">
                <span class="rank">${medal}</span>
                <div class="task-info">
                    <strong>${t.task}</strong>
                    <span>Importance: ${t.importance} | Urgency: ${t.urgency} | Time: ${t.time}h</span>
                    <div class="score-bar-wrap">
                        <div class="score-bar-fill" style="width:${pct}%; background:${barColor};"></div>
                    </div>
                </div>
                <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px;">
                    <span class="score">Score: ${t.score}</span>
                    <span class="ml-badge">🤖 ML: ${t.ml_score}</span>
                    <span class="formula-badge">📐 Formula: ${t.formula_score}</span>
                </div>
            </div>`;
        });

        document.getElementById('result').innerHTML = html;
        renderChart(tasks);
    });
}

function renderChart(tasks) {
    const section = document.getElementById('chart-section');
    section.style.display = 'block';

    const labels = tasks.map(t => t.task);
    const formulaScores = tasks.map(t => t.formula_score);
    const mlScores = tasks.map(t => t.ml_score);

    if (chartInstance) chartInstance.destroy();

    const ctx = document.getElementById('scoreChart').getContext('2d');
    chartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels,
            datasets: [
                {
                    label: 'Formula Score',
                    data: formulaScores,
                    backgroundColor: 'rgba(99, 102, 241, 0.7)',
                    borderRadius: 8,
                    borderSkipped: false,
                },
                {
                    label: 'ML Score',
                    data: mlScores,
                    backgroundColor: 'rgba(167, 139, 250, 0.7)',
                    borderRadius: 8,
                    borderSkipped: false,
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    labels: { color: 'rgba(255,255,255,0.6)', font: { family: 'Inter' } }
                }
            },
            scales: {
                x: { ticks: { color: '#94a3b8', font: { family: 'Inter' } }, grid: { color: 'rgba(255,255,255,0.05)' } },
                y: { beginAtZero: true, ticks: { color: '#94a3b8', font: { family: 'Inter' } }, grid: { color: 'rgba(255,255,255,0.08)' } }
            }
        }
    });
}

