from flask import Flask, render_template, request, jsonify, send_file
import csv
import io
import os
import re
import numpy as np
from sklearn.linear_model import LinearRegression # type: ignore

# Ye Flask app ka entry point hai.
# Har ek route aur parsing logic is app me handle hoti hai.
app = Flask(__name__)

tasks = []
ml_model = None

# Training data. machine learning model ke liye.
# Ye data importance, urgency, time, aur actual priority ko define karta hai.
training_data = [
    {"importance": 5, "urgency": 5, "time": 1, "actual_priority": 5},
    {"importance": 5, "urgency": 4, "time": 2, "actual_priority": 4.5},
    {"importance": 4, "urgency": 5, "time": 1, "actual_priority": 4.8},
    {"importance": 4, "urgency": 3, "time": 3, "actual_priority": 3.5},
    {"importance": 3, "urgency": 3, "time": 2, "actual_priority": 3},
    {"importance": 3, "urgency": 2, "time": 4, "actual_priority": 2.5},
    {"importance": 2, "urgency": 2, "time": 1, "actual_priority": 2},
    {"importance": 2, "urgency": 1, "time": 3, "actual_priority": 1.5},
    {"importance": 1, "urgency": 1, "time": 2, "actual_priority": 1},
    {"importance": 1, "urgency": 1, "time": 8, "actual_priority": 0.5},
    {"importance": 5, "urgency": 3, "time": 5, "actual_priority": 3.5},
    {"importance": 4, "urgency": 4, "time": 2, "actual_priority": 4},
    {"importance": 3, "urgency": 4, "time": 1, "actual_priority": 3.8},
    {"importance": 2, "urgency": 3, "time": 2, "actual_priority": 2.5},
    {"importance": 5, "urgency": 2, "time": 6, "actual_priority": 3},
]

# Ye function ML model ko train karta hai training_data ke saath.
# Isse model future task score predict kar sakta hai.
def train_model():
    global ml_model
    X = np.array([[d["importance"], d["urgency"], d["time"]] for d in training_data])
    y = np.array([d["actual_priority"] for d in training_data])
    ml_model = LinearRegression()
    ml_model.fit(X, y)


# Ye function natural language task text se entities nikalta hai.
# Ye task name, importance, urgency, aur estimated time ko parse karta hai.
def extract_entities(text):
    text = (text or "").strip()
    if not text:
        return {"task": "", "importance": 3, "urgency": 3, "time": 1}

    lower = text.lower()
    normalization_map = {
        "tommorow": "tomorrow",
        "tommorrow": "tomorrow",
        "tomorow": "tomorrow",
        "urgently": "urgent",
        "urgenty": "urgent",
        "urgentl": "urgent",
        "immediatly": "immediately",
        "importnt": "important",
        "importantt": "important",
        "as soon as possible": "asap",
        "asap": "asap"
    }
    for wrong, right in normalization_map.items():
        lower = lower.replace(wrong, right)

    lower = re.sub(r"\b(or it will rot|or it will spoil|or it will go bad|or else|otherwise|because|so that|for now)\b", "", lower)

    importance = None
    urgency = None
    time = None
    time_word_map = {
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9,
        "ten": 10
    }

    label_patterns = {
        "importance": r"importance\s*(?:is|=|:)?\s*([1-5])",
        "urgency": r"urgency\s*(?:is|=|:)?\s*([1-5])",
        "time": r"time\s*(?:is|=|:)?\s*([0-9]+(?:\.[0-9]+)?)\s*(?:h(?:ours?)?|hrs?|hours?|hr|minutes?|mins?)?\b"
    }

    explicit_importance = re.search(label_patterns["importance"], lower)
    if explicit_importance:
        importance = int(explicit_importance.group(1))
        lower = re.sub(label_patterns["importance"], "", lower)

    explicit_urgency = re.search(label_patterns["urgency"], lower)
    if explicit_urgency:
        urgency = int(explicit_urgency.group(1))
        lower = re.sub(label_patterns["urgency"], "", lower)

    explicit_time = re.search(label_patterns["time"], lower)
    if explicit_time:
        time = float(explicit_time.group(1))
        lower = re.sub(label_patterns["time"], "", lower)

    importance_patterns = {
        5: [r"very important", r"extremely important", r"super important", r"critical", r"urgent", r"must do", r"highest priority", r"need to do"],
        4: [r"(?<!not\s)important", r"high priority", r"(?<!low\s)priority", r"should do", r"needed soon", r"really important"],
        2: [r"low priority", r"not very important", r"optional", r"if time allows", r"less important", r"not that important"],
        1: [r"least important", r"not important", r"can wait", r"not urgent"]
    }

    urgency_patterns = {
        5: [r"right now", r"asap", r"as soon as possible", r"immediately", r"urgent", r"urgently", r"this moment", r"must do it", r"need it now", r"have to"],
        4: [r"today", r"by today", r"before today", r"before tomorrow", r"later today", r"tonight"],
        3: [r"tomorrow", r"by tomorrow", r"next day", r"soon", r"tommorrow"],
        2: [r"this week", r"in a few days", r"next week", r"later"],
        1: [r"no deadline", r"whenever", r"sometime", r"can wait", r"not urgent"]
    }

    if time is None:
        time_match = re.search(r"(\d+(?:\.\d+)?)\s*(?:h(?:ours?)?|hrs?|hours?|hr)\b", lower)
        if time_match:
            time = float(time_match.group(1))
            lower = re.sub(time_match.group(0), "", lower)
        else:
            time_word_match = re.search(r"\b(one|two|three|four|five|six|seven|eight|nine|ten)\s*(?:h(?:ours?)?|hrs?|hours?|hr)\b", lower)
            if time_word_match:
                time = float(time_word_map[time_word_match.group(1)])
                lower = re.sub(time_word_match.group(0), "", lower)
            else:
                min_match = re.search(r"(\d+(?:\.\d+)?)\s*(?:minutes?|mins?)\b", lower)
                if min_match:
                    time = float(min_match.group(1)) / 60.0
                    lower = re.sub(min_match.group(0), "", lower)
                else:
                    min_word_match = re.search(r"\b(one|two|three|four|five|six|seven|eight|nine|ten)\s*(?:minutes?|mins?)\b", lower)
                    if min_word_match:
                        time = float(time_word_map[min_word_match.group(1)]) / 60.0
                        lower = re.sub(min_word_match.group(0), "", lower)
                    elif re.search(r"\bhalf\s+(?:hour|hr)\b", lower):
                        time = 0.5
                        lower = re.sub(r"\bhalf\s+(?:hour|hr)\b", "", lower)
                    elif re.search(r"\bquarter\s+(?:hour|hr)\b", lower):
                        time = 0.25
                        lower = re.sub(r"\bquarter\s+(?:hour|hr)\b", "", lower)

    if importance is None:
        for score, patterns in importance_patterns.items():
            for pattern in patterns:
                if re.search(r"\b" + pattern + r"\b", lower):
                    importance = score
                    lower = re.sub(r"\b" + pattern + r"\b", "", lower)
                    break
            if importance is not None:
                break

    if urgency is None:
        for score, patterns in urgency_patterns.items():
            for pattern in patterns:
                if re.search(r"\b" + pattern + r"\b", lower):
                    urgency = score
                    lower = re.sub(r"\b" + pattern + r"\b", "", lower)
                    break
            if urgency is not None:
                break

    if importance is None:
        number_importance = re.search(r"\bimportance\s*[:=\-]?\s*([1-5])\b", lower)
        if number_importance:
            importance = int(number_importance.group(1))
            lower = re.sub(number_importance.group(0), "", lower)

    if urgency is None:
        number_urgency = re.search(r"\burgency\s*[:=\-]?\s*([1-5])\b", lower)
        if number_urgency:
            urgency = int(number_urgency.group(1))
            lower = re.sub(number_urgency.group(0), "", lower)

    if importance is None:
        importance = 3
    if urgency is None:
        urgency = 3
    if time is None:
        time = 1

    # Task name se irrelevant words remove kar raha hai
    # taake task label saaf nazar aaye.
    lower = re.sub(r"\b(in|for|by|on|at|and|with|to|the|a|an|of|this|that|is|will|need|should|please|my|task|task:|have|importance|urgency|time|priority|urgent|important|critical|asap|today|tomorrow|week|later|soon|now|half|quarter|hour|hours|hr|hrs|minutes|mins|deadline|no|sometime)\b", "", lower)
    lower = re.sub(r"[^a-z0-9\s]", " ", lower)
    task_name = re.sub(r"\s+", " ", lower).strip()
    if not task_name:
        task_name = text

    return {
        "task": task_name.title(),
        "importance": importance,
        "urgency": urgency,
        "time": round(time, 2)
    }


# Ye formula based score calculate karta hai based on importance, urgency, aur time.
# Jitni importance aur urgency zyada hogi, score utna hi zyada hoga.
def calculate_score(task):
    return (task["importance"] * 0.5) + (task["urgency"] * 0.4) - (task["time"] * 0.2)


# Ye function trained ML model se score predict karta hai.
# Agar model loaded ho to ye formula se better estimate dene ki koshish karta hai.
def ml_score(task):
    if ml_model is None:
        return None
    X = np.array([[task["importance"], task["urgency"], task["time"]]])
    return round(float(ml_model.predict(X)[0]), 2)


# Model ko start karne ke liye train karte hain jab app load ho.
train_model()


# Home route jahan se frontend page load hota hai.
@app.route("/")
def home():
    return render_template("index.html")

# Ye route frontend se new task add karne ke liye hai.
# Isme parsed task data receive karke score calculate hota hai.
@app.route("/add_task", methods=["POST"])
def add_task():
    data = request.json
    task = {
        "task": data["task"],
        "importance": int(data["importance"]),
        "urgency": int(data["urgency"]),
        "time": int(data["time"])
    }
    task["formula_score"] = round(calculate_score(task), 2)
    task["ml_score"] = ml_score(task)
    task["score"] = task["ml_score"] if task["ml_score"] is not None else task["formula_score"]
    tasks.append(task)
    return jsonify({"message": "Task added successfully", "task": task})

# Ye route current saved tasks ko priority order me return karta hai.
@app.route("/tasks")
def get_tasks():
    sorted_tasks = sorted(tasks, key=lambda x: x["score"], reverse=True)
    return jsonify(sorted_tasks)


# Ye route ML model ki current training status batata hai.
@app.route("/model_status")
def model_status():
    if ml_model is not None:
        coef = ml_model.coef_.tolist()
        return jsonify({
            "trained": True,
            "samples": len(training_data),
            "importance_weight": round(coef[0], 3),
            "urgency_weight": round(coef[1], 3),
            "time_weight": round(coef[2], 3)
        })
    return jsonify({"trained": False, "samples": 0})

# Ye endpoint user ke natural text ko parse karta hai aur entities return karta hai.
@app.route("/ner_parse", methods=["POST"])
def ner_parse():
    data = request.json or {}
    text = data.get("text", "")
    extracted = extract_entities(text)
    return jsonify({"message": "Text parsed successfully", "extracted": extracted})


# Ye route tasks list clear kar deta hai jab page reload ho.
@app.route("/clear_tasks", methods=["POST"])
def clear_tasks():
    tasks.clear()
    return jsonify({"message": "Tasks cleared"})

# Ye unused export route hai agar csv download karna ho.
@app.route("/export_csv")
def export_csv():
    sorted_tasks = sorted(tasks, key=lambda x: x["score"], reverse=True)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Rank', 'Task', 'Importance', 'Urgency', 'Time (hrs)', 'Formula Score', 'ML Score', 'Final Score'])
    for i, t in enumerate(sorted_tasks):
        writer.writerow([
            i+1, t['task'], t['importance'], t['urgency'], t['time'],
            t['formula_score'],
            t['ml_score'] if t['ml_score'] is not None else 'N/A',
            t['score']
        ])
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode()),
        mimetype='text/csv',
        as_attachment=True,
        download_name='tasks.csv'
    )

# Ye unused save route hai agar tasks ko server side csv me save karna ho.
@app.route("/save_csv")
def save_csv():
    sorted_tasks = sorted(tasks, key=lambda x: x["score"], reverse=True)
    filepath = os.path.join(os.path.dirname(__file__), 'tasks.csv')
    with open(filepath, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Rank', 'Task', 'Importance', 'Urgency', 'Time (hrs)', 'Formula Score', 'ML Score', 'Final Score'])
        for i, t in enumerate(sorted_tasks):
            writer.writerow([
                i+1, t['task'], t['importance'], t['urgency'], t['time'],
                t['formula_score'],
                t['ml_score'] if t['ml_score'] is not None else 'N/A',
                t['score']
            ])
    return jsonify({"message": "CSV saved to project folder!", "path": filepath})

if __name__ == "__main__":
    app.run(debug=True)